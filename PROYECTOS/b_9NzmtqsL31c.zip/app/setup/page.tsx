'use client'

import { useRouter } from 'next/navigation'
import { useEffect } from 'react'

export default function SetupPage() {
  const router = useRouter()

  useEffect(() => {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

    const isConfigured = supabaseUrl && supabaseKey

    if (isConfigured) {
      router.push('/dashboard')
    }
  }, [router])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-8">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-primary/20 rounded-lg mb-4">
            <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-900">Configuration Complete</h1>
        </div>

        <div className="space-y-4 mb-6">
          <p className="text-sm text-gray-600">
            Supabase variables are configured. Redirecting to dashboard...
          </p>

          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h3 className="font-semibold text-green-900 text-sm mb-2">Environment Status:</h3>
            <ul className="text-sm text-green-800 space-y-1">
              <li>✓ NEXT_PUBLIC_SUPABASE_URL configured</li>
              <li>✓ NEXT_PUBLIC_SUPABASE_ANON_KEY configured</li>
            </ul>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <h3 className="font-semibold text-blue-900 text-sm mb-2">Quick Start:</h3>
            <ol className="text-sm text-blue-800 space-y-1">
              <li>1. Wait for redirect to Dashboard</li>
              <li>2. Or click the button below to continue</li>
            </ol>
          </div>
        </div>

        <button
          onClick={() => router.push('/dashboard')}
          className="w-full bg-primary text-primary-foreground font-semibold py-2 px-4 rounded-lg hover:bg-primary/90 transition-colors"
        >
          Go to Dashboard
        </button>

        <div className="text-center mt-4">
          <p className="text-xs text-gray-500">
            Redirecting automatically in a few seconds...
          </p>
        </div>
      </div>
    </div>
  )
}
