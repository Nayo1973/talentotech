'use client'

import { useState, useEffect } from 'react'
import { Droplet, TrendingUp, AlertCircle, CheckCircle } from 'lucide-react'

export default function DemoPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const kpiData = {
    total_transfusions: 145,
    appropriate_count: 95,
    inappropriate_count: 32,
    questionable_count: 18,
    red_blood_cells: 82,
    plasma: 38,
    platelets: 25,
  }

  const auditRecords = [
    { id: 1, patient_id: 'PAC-00001', age: 45, gender: 'M', transfusion_type: 'RBC', indication: 'Anemia Hb < 7', rating: 'Adecuada', date: '2026-04-20' },
    { id: 2, patient_id: 'PAC-00002', age: 72, gender: 'F', transfusion_type: 'RBC', indication: 'Perioperative', rating: 'Adecuada', date: '2026-04-19' },
    { id: 3, patient_id: 'PAC-00003', age: 58, gender: 'M', transfusion_type: 'FFP', indication: 'Coagulopathy', rating: 'Adecuada', date: '2026-04-18' },
    { id: 4, patient_id: 'PAC-00004', age: 35, gender: 'F', transfusion_type: 'PLT', indication: 'Thrombocytopenia', rating: 'Dudosa', date: '2026-04-17' },
    { id: 5, patient_id: 'PAC-00005', age: 68, gender: 'M', transfusion_type: 'RBC', indication: 'Preoperative', rating: 'Inadecuada', date: '2026-04-16' },
    { id: 6, patient_id: 'PAC-00006', age: 52, gender: 'F', transfusion_type: 'RBC', indication: 'Symptomatic', rating: 'Adecuada', date: '2026-04-15' },
    { id: 7, patient_id: 'PAC-00007', age: 81, gender: 'M', transfusion_type: 'FFP', indication: 'INR > 2', rating: 'Dudosa', date: '2026-04-14' },
    { id: 8, patient_id: 'PAC-00008', age: 42, gender: 'F', transfusion_type: 'PLT', indication: 'Bleeding', rating: 'Adecuada', date: '2026-04-13' },
  ]

  const getRatingColor = (rating: string) => {
    switch (rating) {
      case 'Adecuada': return 'bg-green-100 text-green-800'
      case 'Inadecuada': return 'bg-red-100 text-red-800'
      case 'Dudosa': return 'bg-yellow-100 text-yellow-800'
      default: return 'bg-gray-100'
    }
  }

  const appropriatePercentage = ((kpiData.appropriate_count / kpiData.total_transfusions) * 100).toFixed(1)
  const inappropriatePercentage = ((kpiData.inappropriate_count / kpiData.total_transfusions) * 100).toFixed(1)
  const questionablePercentage = ((kpiData.questionable_count / kpiData.total_transfusions) * 100).toFixed(1)

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Droplet className="w-8 h-8 text-teal-600" />
              <h1 className="text-2xl font-bold text-teal-600">Auditar</h1>
            </div>
            <p className="text-sm text-gray-600">Hospital Universitario Susana López</p>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold">Dashboard de Auditoría</h2>
          <p className="text-gray-600 mt-2">Datos de prueba del sistema de transfusiones</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-600 text-sm mb-2">Total Transfusiones</p>
            <p className="text-3xl font-bold">{kpiData.total_transfusions}</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-600 text-sm mb-2">Adecuadas</p>
            <p className="text-3xl font-bold text-green-600">{kpiData.appropriate_count}</p>
            <p className="text-xs text-gray-500 mt-1">{appropriatePercentage}%</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-600 text-sm mb-2">Inadecuadas</p>
            <p className="text-3xl font-bold text-red-600">{kpiData.inappropriate_count}</p>
            <p className="text-xs text-gray-500 mt-1">{inappropriatePercentage}%</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <p className="text-gray-600 text-sm mb-2">Dudosas</p>
            <p className="text-3xl font-bold text-yellow-600">{kpiData.questionable_count}</p>
            <p className="text-xs text-gray-500 mt-1">{questionablePercentage}%</p>
          </div>
        </div>

        {/* Components */}
        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <h3 className="text-lg font-semibold mb-4">Distribución de Componentes</h3>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-gray-600 mb-2">Eritrocitos (RBC)</div>
              <div className="text-2xl font-bold mb-2">{kpiData.red_blood_cells}</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-red-600 h-2 rounded-full" style={{ width: `${(kpiData.red_blood_cells / kpiData.total_transfusions) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-2">Plasma (FFP)</div>
              <div className="text-2xl font-bold mb-2">{kpiData.plasma}</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${(kpiData.plasma / kpiData.total_transfusions) * 100}%` }} />
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-2">Plaquetas (PLT)</div>
              <div className="text-2xl font-bold mb-2">{kpiData.platelets}</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{ width: `${(kpiData.platelets / kpiData.total_transfusions) * 100}%` }} />
              </div>
            </div>
          </div>
        </div>

        {/* Legend */}
        <div className="bg-white p-6 rounded-lg shadow mb-8">
          <h3 className="text-lg font-semibold mb-4">Sistema de Semáforo</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="p-4 bg-green-50 rounded border border-green-200">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <p className="font-semibold text-green-900">Adecuada</p>
              </div>
              <p className="text-sm text-green-800">Hb &lt; 7 g/dL con indicación clara</p>
            </div>
            <div className="p-4 bg-red-50 rounded border border-red-200">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <p className="font-semibold text-red-900">Inadecuada</p>
              </div>
              <p className="text-sm text-red-800">Hb &gt; 10 g/dL sin indicación</p>
            </div>
            <div className="p-4 bg-yellow-50 rounded border border-yellow-200">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-yellow-600" />
                <p className="font-semibold text-yellow-900">Dudosa</p>
              </div>
              <p className="text-sm text-yellow-800">Hb 7-10 g/dL, requiere evaluación</p>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold">Registros de Auditoría</h3>
          </div>
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold">Paciente</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Edad/Sexo</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Componente</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Indicación</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Estado</th>
                <th className="px-6 py-3 text-left text-sm font-semibold">Fecha</th>
              </tr>
            </thead>
            <tbody>
              {auditRecords.map((record) => (
                <tr key={record.id} className="border-b hover:bg-gray-50">
                  <td className="px-6 py-4 font-medium">{record.patient_id}</td>
                  <td className="px-6 py-4 text-sm">{record.age} {record.gender}</td>
                  <td className="px-6 py-4 text-sm">{record.transfusion_type}</td>
                  <td className="px-6 py-4 text-sm">{record.indication}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRatingColor(record.rating)}`}>
                      {record.rating}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">{record.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  )
}
